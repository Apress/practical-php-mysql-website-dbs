<style type="text/css">
#header { 	margin:10px auto 0 auto; min-width:960px; max-width:1200px; height:175px; background-image: url('images/tile-pale.jpg'); 
background-repeat: repeat; padding:0; color:white;	
}
h1 {position:relative; top:40px; font-size:350%; color:white; margin:auto 0 auto 20px; 	width: 487px;
}
#reg-navigation ul { float:right;
	font-size:medium; width:160px; margin:-150px 15px 0 88%;
</style>
<div id="header">
<h1>This is the header</h1>
<div id="reg-navigation">
		<ul>
			<li><a href="register-page.php">Register</a></li>
			<li><a href="register-view_users-page.php">View Users</a></li>
			<li><a href="register-password.php">New Password</a></li>
		</ul>
	</div>

</div>
