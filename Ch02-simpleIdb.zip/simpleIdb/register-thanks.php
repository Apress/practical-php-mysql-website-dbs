<!doctype html>
<html lang="en">
<head>
<title>Registion thank you page</title>
<meta charset=utf-8>
<link rel="stylesheet" type="text/css" href="includes.css">
</head>
<body>
<div id="container">
<?php include("header.php"); ?>
<?php include("nav.php"); ?>
<?php include("info-col.php"); ?>
	<div id="content"><!-- Start of the page-specific content. -->
<h2>Thank you for registering</h2>
<p>The thank you page content. The thank you page content. The thank you page content.<br>The page 
five content. The thank you page content. The thank you page content.<br>The thank you page content. The page 
five content. The thank you page content.<br>The thank you page content. The thank you page content. The page 
five content.</p>
	<!-- End of the page-specific content. --></div>
</div>	
<?php include("footer.php"); ?>
</body>
</html>