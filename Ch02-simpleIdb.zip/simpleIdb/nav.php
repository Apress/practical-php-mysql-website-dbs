<style type="text/css">
ul { position:absolute; top:190px; left:-10px; color:navy; width:135px; text-align:center; margin:0;
}
/* set general side button styles */
li { width:115px; list-style-type :none; margin-bottom: 3px; text-align: center;
}
/* set general anchor styles */
li a { display: block; width:115px; color: white; font-weight: bold; text-decoration: none
}
/* specify state styles. */
/* mouseout (default) */
li a { background: #5B78BE; border: 4px outset #aabaff;
}
/* mouseover */
li a:hover { display:block; background: #0a4adf; border: 4px outset #8abaff; width:115px;
}
/* onmousedown */
li a:active { background:#aecbff; border: 4px inset #aecbff;
</style>
<div id="nav"><!--This side menu column contains the vertical menu-->
<ul>
<li><a href="page-2.php" title="Page two">Page 2</a></li>
<li><a href="page-3.php" title="Page three">Page 3</a></li>
<li><a href="page-4.php" title="Page four">Page 4</a></li>
<li><a href="page-5.php" title="Page five">Page 5</a></li>
<li><a href="index.php" title="Return to Home Page">Home Page</a></li>
</ul>
</div><!--end of side column and menu -->
