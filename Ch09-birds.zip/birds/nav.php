<div id="nav"><!--The side menu column contains the vertical menu-->
<ul>
<li><a href="#" title="Page two">About Us</a></li>
<li><a href="birds.php" title="The Birds">The Birds</a></li>
<li><a href="reserves.php" title="The Reserves">The Reserves</a></li>
<li><a href="joined.php" title="Page five">Joined Tables</a></li>
<li><a href="index.php" title="Return to Home Page">Home Page</a></li>
</ul>
</div><!--end of side column and menu -->