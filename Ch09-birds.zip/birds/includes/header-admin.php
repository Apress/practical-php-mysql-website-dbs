<div id="header-admin">
<h1>The Devon Bird Reserves</h1>
<div id="reg-navigation">
		<ul>
			<li><a href="logout.php">Logout</a></li>
			<li><a href="admin_view_users.php">View Members</a></li>
			<li><a href="search.php">Search</a></li>
			<li><a href="search_addresses.php">Addresses</a></li>
			<li><a href="register-password.php">New Password</a></li>
		</ul>
</div>
</div>