<!doctype html>
<html lang=en>
<head>
<title>Template for an interactive database</title>
<meta charset=utf-8>
<link rel="stylesheet" type="text/css" href="birds.css">
</head>
<body>
<div id='container'>
<?php include('includes/header.php'); ?>
<?php include('includes/nav.php'); ?>
<?php include('includes/info-col.php'); ?>
	<div id='content'><!--Start of page content.-->
<div id="midcol">
<h2>This is the Template Page</h2>
<p>Paying by Check<br>Thank you for registering online, please now fill out this 
form and send it together with your check to the following address. When you 
have filled out the form please rprint two copies by clicking the "Print This 
Form" button, sign one copy and mail it to: </p>
	<p>Treasurer, The Devon Bird Reserves,The City,&nbsp; 99 The Street, EX99 
	99ZZ </p>
	<p>&nbsp;</p>
	<p>nt. The home page content. The home page content. The home page content. <br>The home page content. The home page content. <br>The home page content. The home page content. The home page content. </p>
	<!--End of the template content.--></div>
</div>	</div>
<?php include('includes/footer.php'); ?>
</body>
</html>