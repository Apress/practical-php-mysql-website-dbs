<div id="header">
<h1>This is the header</h1>
<div id="reg-navigation">
	<ul>
		<li><a href="register-page.php">Erase Entries</a></li>
	</ul>
</div>
</div>