<div id="header-members">
<h1>This is the header</h1>
<div id="reg-navigation">
		<ul>
			<li><a href="logout.php">Logout</a></li>
			<li><a href="register-password.php">New Password</a></li>
		</ul>
	</div>
</div>
