<div id="info-col">
<h3>This is the information column</h3>
	<p>Web design by <br>A W West</p>
	<img alt="Pay by PayPal or Credit card" title="Pay by PayPal or Credit card"src="images/vertical_solution_PP.png">
</div>
