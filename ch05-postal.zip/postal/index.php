<!doctype html>
<html lang=en>
<head>
<title>Index-register</title>
<meta charset=utf-8>
<link rel="stylesheet" type="text/css" href="includes.css">
</head>
<body>
<div id="container">
<?php include("header.php"); ?>
<?php include("nav.php"); ?>
<?php include("info-col.php"); ?>
	<div id="content"><!-- Start of the page-specific content. -->
<h2>This is the Home Page</h2>
<p>The home page content. The home page content. The home page content. The home page content. The home page content. <br>The home page content. The home page content. The home page content. The home page content. <br>The home page content. The home page content. <br>The home page content. The home page content. The home page content. </p>
	<!-- End of the page-specific content. --></div>
</div>	
	<!--<div id="footer">
		<p style="height: 19px">Copyright &copy; Adrian West 2012 | Designed by <a href="http://www.colycomputerhelp.co.uk/">Adrian West</a> | Valid <a href="http://jigsaw.w3.org/css-validator/">CSS</a> &amp; 
		<a href="http://validator.w3.org/">HTML5</a></p>
	</div>-->
<?php include("footer.php"); ?>
	
</body>
</html>