<!doctype html>
<html lang=en>
<head>
<title>Registration thank you page</title>
<meta charset=utf-8>
<link rel="stylesheet" type="text/css" href="msgboard.css">
<style type="text/css">
p { text-align:center; }
#tab-navigation ul { position:absolute; top: 135px; left:500px; }
</style>
</head>
<body>
<div id="container">
<?php include("includes/header_register.php"); ?>
<?php include("includes/info-col.php"); ?>
	<div id="content"><!--Start of the thank you page content-->
<div id="midcol">
<h2>Thank you for registering</h2>
<h3>On the Home Page, you will now be able to login and add new quotes to the message board.</h3>
</div>
</div></div>
	<!--End of the thankyou page content-->
<?php include("includes/footer.php"); ?>
</body>
</html>