<div id="footer">
		<p>Copyright &copy; Adrian West 2013| Designed by <a href="http://www.colycomputerhelp.co.uk/">Adrian 
		W West</a> </p>
</div>