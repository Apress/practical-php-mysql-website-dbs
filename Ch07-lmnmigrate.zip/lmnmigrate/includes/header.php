<div id="header">
<h1>This is the header</h1>
<div id="reg-navigation">
		<ul>
			<li><a href="login.php">Login</a></li>
			<li><a href="safer-register-page.php">Register</a></li>
		</ul>
	</div>
</div>
