<div id="header">
<h1>This is the header</h1>
<div id="reg-navigation">
	<ul>
		<li><a href="register-password.php">Erase Entries</a></li>
		<li><a href="index.php">Cancel</a></li>
	</ul>
</div>
</div>

