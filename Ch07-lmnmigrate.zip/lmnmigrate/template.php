<!doctype html>
<html lang=en>
<head>
<title>Template for an interactive database</title>
<meta charset=utf-8>
<link rel="stylesheet" type="text/css" href="includes.css">
</head>
<body>
<div id='container'>
<?php include('includes/header-for-template.php'); ?>
<?php include('includes/nav.php'); ?>
<?php include('includes/info-col.php'); ?>
	<div id='content'><!--Start of page content.-->
<h2>This is the Home Page</h2>
<p>The home page content. The home page content. The home page content. The home page content. The home page content. <br>The home page content. The home page content. The home page content. The home page content. <br>The home page content. The home page content. <br>The home page content. The home page content. The home page content. </p>
	<!--End of the template content.--></div>
</div>	
<?php include('includes/footer.php'); ?>
</body>
</html>